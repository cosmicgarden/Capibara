package taxon_record.sib;

import java.util.Date;

public class Version {
	private int major;
	
	private int minor;
	
	private int modifier;
	
	private Date dateIssued;
	
	private int preferredFlag;
}
