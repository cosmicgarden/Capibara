package taxon_record.sib;

import java.util.List;

import com.google.common.collect.Lists;

public class TargetAudiencesEntity {
	//*
	private List<String> audience = Lists.newArrayList();
	
	private String audiencesUnstructured;

}
