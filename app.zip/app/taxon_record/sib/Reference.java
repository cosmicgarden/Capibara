package taxon_record.sib;

public class Reference {
	private String ref;
	
	//op
	private String linkType; //select between three types: local, external, other
	
}
