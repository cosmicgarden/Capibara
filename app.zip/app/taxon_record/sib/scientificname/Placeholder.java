package taxon_record.sib.scientificname;

import java.util.List;

public class Placeholder {
	//op
	private List<String> anyOne;
	
	private String anyTwo;
}
