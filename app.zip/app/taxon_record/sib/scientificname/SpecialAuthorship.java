package taxon_record.sib.scientificname;

import java.util.List;

import com.google.common.collect.Lists;

public class SpecialAuthorship {
	/*
	 * 
	 */
	private NameCitation basionymAuthorship;
	
	/*
	 * Es una lista?
	 */
	private List<NameCitation> combinationAuthorship =Lists.newArrayList();
}
