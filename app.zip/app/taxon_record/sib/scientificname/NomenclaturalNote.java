package taxon_record.sib.scientificname;

import taxon_record.sib.Reference;

public class NomenclaturalNote {
	
	/*
	 * Opti
	 */
	private String ruleConsidered;
	
	/*
	 * Opti
	 */
	private String Note;
	
	/*
	 * Opti
	 */
	private Reference relatedName;
	
	/*
	 * Opti
	 */
	private Reference publishedIn;
	
	/*
	 * Opti
	 */
	private String microReference;
	
}
