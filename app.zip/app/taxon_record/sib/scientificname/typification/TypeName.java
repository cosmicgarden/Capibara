package taxon_record.sib.scientificname.typification;

import taxon_record.sib.Reference;

public class TypeName {
	
	private Reference nameReference; //ReferenceType
	
	private Reference lectotypePublication; //ReferenceType
	
	private Reference lectotypeMicroReference; //ReferenceType

}
