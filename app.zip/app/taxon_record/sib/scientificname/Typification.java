package taxon_record.sib.scientificname;

import taxon_record.sib.scientificname.typification.TypeName;
import taxon_record.sib.scientificname.typification.TypeVoucher;

public class Typification {
	/*
	 * 
	 */
	private String simple;
	
	//choice
	
	/*
	 * 
	 */
	private TypeVoucher typeVoucherEntity;
	
	//---
	/*
	 * 
	 */
	private TypeName typeNameEntity;
	
	//end choice
}
