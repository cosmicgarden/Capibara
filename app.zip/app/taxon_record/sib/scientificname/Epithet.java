package taxon_record.sib.scientificname;

public class Epithet {

	//choice
	/*
	 * 
	 */
	private String InfragenericEpithet;
	
	//--
	/*
	 * 
	 */
	private String SpecificEpithet;
	
	/*
	 * 
	 */
	private String InfraspecificEpithet;
	// end choice
}
