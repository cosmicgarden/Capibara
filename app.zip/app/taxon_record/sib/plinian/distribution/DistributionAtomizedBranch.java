package taxon_record.sib.plinian.distribution;

import java.util.List;

import com.google.common.collect.Lists;

import taxon_record.sib.AncillaryData;

public class DistributionAtomizedBranch {
	/*
	 * Obli
	 */
	//private List<DistributionAtomizedType> distributionAtomized;
	private DistributionAtomizedType distributionAtomized;
	
	/*
	 * Opt
	 */
	private List<AncillaryData> ancillaryData =Lists.newArrayList();
	//private AncillaryData ancillaryData;
}
