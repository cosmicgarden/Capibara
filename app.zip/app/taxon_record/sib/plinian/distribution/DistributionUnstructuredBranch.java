package taxon_record.sib.plinian.distribution;

import java.util.List;

import taxon_record.sib.AncillaryData;

public class DistributionUnstructuredBranch {
	
	/*
	 * Obl
	 */
	private String distributionUnstructured;
	
	/*
	 * Opt
	 */
	private List<AncillaryData> ancillaryData;

}
