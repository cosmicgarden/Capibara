package taxon_record.sib.plinian.revision;

import java.util.Date;

import taxon_record.sib.AgentEntity;

public class Revision {

	private AgentEntity associatedParty;
	
	private Date pubDate;
	
	private Date created;
}
