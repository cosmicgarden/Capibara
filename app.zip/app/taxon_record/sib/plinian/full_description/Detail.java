package taxon_record.sib.plinian.full_description;

import java.util.Date;
import java.util.List;

import taxon_record.sib.AncillaryData;


public class Detail {
	/*
	 * Opt
	 */
	private List<MeasurementOrFact> measurementOrFact;
	
	/*
	 * Opt
	 */
	private List<AncillaryData> AncillaryData;
}
