package taxon_record.sib.plinian.molecuar_data;

import java.util.List;

import taxon_record.sib.AncillaryData;

import com.google.common.collect.Lists;

public class MolecularDataAtomizedBranch {
	/*
	 * Obli
	 * Tiene AncillaryData
	 */
	private MolecularDataAtomized molecularDataAtomized;
	
	/*
	 * Opt
	 */
	private List<AncillaryData> ancillaryData =Lists.newArrayList();

}
