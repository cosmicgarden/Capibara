package taxon_record.sib.plinian.synonyms;

import taxon_record.sib.AncillaryData;
import taxon_record.sib.scientificname.ScientificName;

public class SynonymsAtomized {
	
	private ScientificName SynonymName;
	
	private String SynonymStatus;
	
	private AncillaryData AncillaryData;

}
