package taxon_record.sib.plinian.migratory;

public class Migratory {

}
