package taxon_record.sib.plinian.interactions;

import java.util.List;

import taxon_record.sib.AncillaryData;

import com.google.common.collect.Lists;

public class InteractionsAtomizedBranch {
	/*
	 * Obli
	 * Tiene AncillaryData
	 */
	private InteractionsAtomized interactionsAtomized;
	
	/*
	 * Opt
	 */
	private List<AncillaryData> ancillaryData =Lists.newArrayList();
	
}
