package taxon_record.sib.plinian.feeding;

import java.util.List;

import taxon_record.sib.AncillaryData;

public class FeedingAtomizedBranch {
	
	/*
	 * Obl
	 */
	private FeedingAtomized feedingAtomized;
	
	/*
	 * Opt
	 */
	private List<AncillaryData> ancillaryData;
	//private AncillaryData ancillaryData;

}
